import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:fyp_industrial_watch/screens/ReadingAnalogDisplay/predict_screen.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:path/path.dart' as path;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../../api/ipaddress.dart';
import '../../customs/customtext.dart';
import '../../customs/custumbutton.dart';
import '../../model/users.dart';
import '../supervisor/employee_productivity/employee_data.dart';
import 'allRecord.dart';
import 'meter_model.dart';
import 'package:http/http.dart' as http;

class Metercreen extends StatefulWidget {
  //const Metercreen({Key? key}) : super(key: key);

  List<Users> ulist=[];
  Metercreen(this.ulist);
  @override
  State<Metercreen> createState() => _MetercreenState();
}

class _MetercreenState extends State<Metercreen> {

  String? selected;
  String? gval;
  List<String> itemlist=[];
  List<DropdownMenuItem<String>> getItems() {
    List<DropdownMenuItem<String>> dlist = [];
    itemlist.forEach((element) {
      DropdownMenuItem<String> dropitem = DropdownMenuItem(
          value: element,
          child: Text(element, style: TextStyle(fontSize: 20),)
      );
      dlist.add(dropitem);
    });
    return dlist;
  }

  XFile? imgfile;
  File? file;
  String scanText="";
/*

  void getImage(ImageSource source) async{
    try {
      final pickedimage= await ImagePicker().pickImage(source: source);
        imgfile=pickedimage;
        {

          _sendImageToServer();
        setState(() {});
        }
    }catch(e){
      imgfile =null;
      scanText="Error accoured :";
    }}
*/

  File? img;

  Uint8List? _imageBytes;

  Future<void> _sendImageToServer() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    final fileBytes = await pickedFile!.readAsBytes();
    final request = http.MultipartRequest(
      'GET',
      Uri.parse('${ip}/getmodel'),
    );
    final multipartFile = http.MultipartFile.fromBytes(
      'img',
      fileBytes,
      filename: 'model.jpg',
    );
    request.fields["type"] = 1.toString();
    request.files.add(multipartFile);
    final response = await request.send();

    if (response.statusCode == 200) {
      final responseBytes = await response.stream.toBytes();
      setState(() {
        _imageBytes = responseBytes;
      });
    } else {
      throw Exception('Failed to send image');
    }
  }
  getImg() {
    if (_imageBytes != null) {
      return Container(
          height: (MediaQuery
              .of(context)
              .size
              .height) * 0.35,
          width: (MediaQuery
              .of(context)
              .size
              .width) * 0.80,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: MemoryImage(_imageBytes!),
              fit: BoxFit.fill,
            ),
          ));
    }
    {
      return Container(
        height: (MediaQuery.of(context).size.height) * 0.25,
        width: (MediaQuery.of(context).size.width) * 0.37,
        color: Color.fromARGB(255, 247, 245, 245),
        child: Icon(
          Icons.person,
          size: 140,
        ),
      );
    }
  }


  bool flg=false;

  void initState() {
    getMeters();
  }

  Meter mtr=new Meter();
  List<Meter> mlist=[];

  getMeters()async{
    mlist=await mtr.getAllMeter(widget.ulist[0].org_id);
    for(var e in mlist){
      itemlist.add(e.meter_name);
    }
    setState(() {
    });
    print("Length -----------------------"+itemlist.length.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 0, 53, 103),
      appBar: AppBar(title: Text('Meter Screen'),),
       body:SingleChildScrollView(
        child:
        Padding(
         padding: const EdgeInsets.all(25.0),
        child:
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // if(imgfile== null)
            //   Container(
            //   height: 300,
            //   width: 300,
            //   child: Image.asset('assets/images/OIP (15).jpg',
            //   fit: BoxFit.fill,
            //   ),),
            // if(imgfile!=null)
            //   Container(
            //   height: 270,width: 200,
            //    child:Image.file(File(imgfile!.path,),fit: BoxFit.fill,),
            //   ),
            getImg(),
            SizedBox(height: 20,),
            InputDecorator(
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(width: 2, color: Colors.white),
                  borderRadius:
                  const BorderRadius.all(Radius.circular(20.0)),
                ),
              ),
              child: DropdownButtonHideUnderline(
                  child: Theme(
                    data: Theme.of(context).copyWith(
                      //canvasColor: Color.fromARGB(255, 119, 235, 253),
                        canvasColor: Colors.black),
                    child: DropdownButton(
                      hint: CustomText("Meter name", Colors.white, 18),
                      value: selected,
                      style: TextStyle(color: Colors.white, fontSize: 18),
                      isDense: true,
                      isExpanded: true,
                      items: getItems(),
                      onChanged: (Value) {
                        setState(() {
                          selected = Value!;
                        });
                      },
                    ),
                  )),
            ),
            SizedBox(height: 10,),
            if(selected!=null)
              Container(
                height: 70,width: 200,
                child: InputDecorator(
                  decoration: const InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white),
                    ),
                  ),child: Column(
                  children: [
                    Text("Unit :  ${mlist.where((element) => element.meter_name==selected).first.meter_unit}",
                      style: TextStyle(fontSize: 30,color: Colors.yellowAccent,fontWeight: FontWeight.bold,fontStyle: FontStyle.italic),
                    ),
                    // SizedBox(height: 10,),
                    // Text("Type : ${mlist.where((element) => element.meter_name==selected).first.meter_type}",
                    //   style:TextStyle(fontSize: 25,color: Colors.yellowAccent,),
                    // ),
                  ],
                ),
                ),
              ),


            // // Container(
            // //   height: 163,width: 270,
            // //   child: InputDecorator(
            // //     decoration: const InputDecoration(
            // //       border: OutlineInputBorder(),
            // //       labelText: ("Type"),
            // //         labelStyle: TextStyle(fontSize: 25,color: Colors.white70),
            // //     ),
            // //     child: Column(
            // //       children: [
            // //         SizedBox(height: 5,),
            // //         RadioListTile(
            // //             title: Text("Analog",style: TextStyle(fontSize: 20,fontWeight: FontWeight.normal,color: Colors.white),),
            // //             value: 'Analog', groupValue: gval, onChanged: (Object? o){
            // //               setState(() {
            // //                 gval=o.toString();
            // //               });
            // //         }),
            // //         SizedBox(height: 5,),
            // //         RadioListTile(
            // //             title: Text("Digital",style: TextStyle(fontSize: 20,fontWeight: FontWeight.normal,color: Colors.white),),
            // //             value: 'Digital', groupValue: gval, onChanged: (Object? o){
            // //               setState(() {
            // //                 gval=o.toString();
            // //               });
            // //         })
            // //       ],
            // //     ),
            // //   ),
            // // ),
            //

            SizedBox(height: 10,),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children:[
            CustomButton(()async{
              _sendImageToServer();
            },'Snap',20,20,20),

            SizedBox(width: 10,),
            CustomButton(()  {
             // getImage(ImageSource.camera);
              setState(() {

              });
            },'Camera',20,20,20),
            ]),
            SizedBox(height:15),
            CustomButton((){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp(),));
            },'Show All',20,20,20),

            SizedBox(height: 10,),
            CustomButton((){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>EmployeeData(),));
            },'Text Recoginition',20,20,20)
      ]
      ),),)
    );
  }
}
