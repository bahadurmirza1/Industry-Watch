import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

import '../../api/ipaddress.dart';

class Meter {
  late int id;
  late String meter_name;
  late String meter_unit,meter_type;
  late int org_id;

  Meter();


  Meter.fromMap(Map<String, dynamic>smap)
  {
    id = smap["id"];
    meter_name = smap["name"];
    meter_unit = smap["unit"];
    meter_type = smap["type"];
  }

  Map<String, dynamic> tomap() {
    Map<String, dynamic> mp = Map<String, dynamic>();
    mp["org_id"] = id;
    mp["meter_name"] = meter_name;
    mp["meter_unit"] = meter_unit;
    mp["meter_type"] = meter_type;
    return mp;
  }

  Future<String?> AddMeterMultipart(Meter m) async
  {
    print("function in");
    String url = '${ip}/add_Meter';
    var request = http.MultipartRequest('POST', Uri.parse(url));
    request.fields["org_id"] = m.org_id.toString();
    request.fields["meter_name"] = m.meter_name;
    request.fields["meter_unit"] = m.meter_unit;
    request.fields["meter_type"] = m.meter_type;
    var response = await request.send();
    if(response.statusCode==200){
      Fluttertoast.showToast(
          msg: "Successfully Save",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          textColor: Colors.white,
          fontSize: 16.0
      );
      return response.stream.bytesToString();
    }
    else{
     return null;
    }
  }

  Future<List<Meter>> getAllMeter(int oid)async{
    String urll='${ip}/get_all_meter';
    var req =http.MultipartRequest('GET',Uri.parse(urll));
    req.fields["org_id"]=oid.toString();
    var resp=await req.send();
    String result = await resp.stream.bytesToString();
    print(result);
    if(resp.statusCode==200){
      print("2000000000000000000000000");
      List jsonlst = jsonDecode(result);
      return jsonlst.map((e) => Meter.fromMap(e)).toList();
    }else{
      return [];
    }
  }
}