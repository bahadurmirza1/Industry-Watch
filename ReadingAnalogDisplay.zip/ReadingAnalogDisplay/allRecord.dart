  import 'package:flutter/material.dart';

class MyApp extends StatefulWidget {
  @override
  _DataTableExample createState() => _DataTableExample();
}

class _DataTableExample extends State<MyApp> {
  List<DataRow> getrows() {
    List<DataRow> drlist = [];
    DataRow obj = DataRow(cells: getcells());
    drlist.add(obj);
    obj = DataRow(cells: getcells());
    drlist.add(obj);
    obj = DataRow(cells: getcells());
    drlist.add(obj);
    obj = DataRow(cells: getcells());
    drlist.add(obj);
    obj = DataRow(cells: getcells());
    drlist.add(obj);
    return drlist;
  }

  List<DataCell> getcells() {
    List<DataCell> dclist = [];
    //Below we Write for Loop
    DataCell obj = DataCell(Container(width: 80, child: Text('Pressure')));
    dclist.add(obj);
    obj = DataCell(Container(width: 60, child: Text('80 ')));
    dclist.add(obj);
    obj = DataCell(Container(width: 60, child: Text('Pa')));
    dclist.add(obj);
    obj = DataCell(Container(width: 60, child: Text('5/1/2023')));
    dclist.add(obj);
    obj = DataCell(Container(width: 60, child: Text('3:37 PM')));
    dclist.add(obj);
    return dclist;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
            appBar: AppBar(
              title: Text('All Record'),
            ),
            body: SingleChildScrollView(
              child: Container(
                  height: 600,
                  child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: <Widget>[
                        DataTable(columns: [
                          DataColumn(
                              label: Text('Meter',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold))),
                          DataColumn(
                              label: Text('Reading',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold))),

                          DataColumn(
                              label: Text('Unit',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold))),
                          DataColumn(
                              label: Text('Date',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold))),
                          DataColumn(
                              label: Text('Time',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold))),
                        ], rows: getrows()
                          //[
                          //   DataRow(cells: [
                          //     DataCell(Text('Using Phone')),
                          //     DataCell(Text('Rs-200')),
                          //     DataCell(Text('5/1/2023')),
                          //     DataCell(Text('3:37 PM'))
                          //   ]),
                          //   DataRow(cells: [
                          //     DataCell(Text('Using Phone')),
                          //     DataCell(Text('Rs-200')),
                          //     DataCell(Text('5/1/2023')),
                          //     DataCell(Text('3:37 PM'))
                          //   ]),
                          //   DataRow(cells: [
                          //     DataCell(Text('Using Phone')),
                          //     DataCell(Text('Rs-200')),
                          //     DataCell(Text('5/1/2023')),
                          //     DataCell(Text('3:37 PM'))
                          //   ]),
                          //   DataRow(cells: [
                          //     DataCell(Text('Using Phone')),
                          //     DataCell(Text('Rs-200')),
                          //     DataCell(Text('5/1/2023')),
                          //     DataCell(Text('3:37 PM'))
                          //   ]),
                          // ],
                        ),
                      ])),
            )));
  }
}
